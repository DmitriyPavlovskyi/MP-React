import React from 'react';
import PropTypes from 'prop-types';

function Test(props) {
  return (
    <h2>Hello world!</h2>
  );
}

Test.propTypes = {

};

export default Test;
