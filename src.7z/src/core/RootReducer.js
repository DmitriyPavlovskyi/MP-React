import { combineReducers } from 'redux';
import todos from '../todos/Reducers/todos';
import visibilityFilter from '../todos/Reducers/visibilityFilter';

const todoApp = combineReducers({
  todos,
  visibilityFilter
});

export default todoApp;
