import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import RootReducer from './RootReducer';
import Test from '../todos/Components/Test';
// import Footer from '../todos/Components/Footer';
// import AddTodo from '../containers/AddTodo';
// import VisibleTodoList from '../todos/Containers/VisibleTodoList';

let store = createStore(RootReducer);

class App extends Component {
  static propTypes = {

  };

  render() {
    return (
      <Provider store={store}>
        <div>
          <Test />
        </div>
      </Provider>
    );
  }
}

export default App;
