export const todoList = [
  {
    id: 1,
    todo: 'Learn React',
    isCompleted: false
  },
  {
    id: 2,
    todo: 'Learn Redux',
    isCompleted: false
  },
  {
    id: 3,
    todo: 'Create todo App',
    isCompleted: false
  }
];
